package provaa;

public class Motorista extends Pessoa {  

    private int numCNH;
    private float salario;
    private String catPrincipal;

    public Motorista() {
    }

    public Motorista(int numCNH, float salario, String catPrincipal) {
        this.numCNH = numCNH;
        this.salario = salario;
        this.catPrincipal = catPrincipal;
    }

    public int getNumCNH() {
        return numCNH;
    }

    public void setNumCNH(int numCNH) {
        this.numCNH = numCNH;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getCatPrincipal() {
        return catPrincipal;
    }

    public void setCatPrincipal(String catPrincipal) {
        this.catPrincipal = catPrincipal;
    }

    public float calculoFerias() {

        float ferias = salario + (salario / 3);
        return ferias;
    }

    public void qtdDeDiasDeFerias() {

        if (catPrincipal == "A") {
            System.out.println("Suas férias será de 28 dias");
        } else if (catPrincipal == "B") {
            System.out.println("Suas férias será de 29 dias");
        } else if (catPrincipal == "C") {
            System.out.println("Suas férias será de 30 dias");
        } else if (catPrincipal == "D") {
            System.out.println("Suas férias será de 31 dias");

        } else if (catPrincipal == "E") {

            System.out.println("Suas férias será de 31 dias");

        }
    }

    public String motoristaCatC() {

        String m = "";
        if (catPrincipal == "C") {

            if (salario > 2000) {

                m = "Motorista: " + getNome() + "\nIdade: " + getIdade() + "\nPeso: " + getPeso() + "\nAltura:" + getAltura() + "\nO salário será: " + salario + "\n";
            }
        }
        return m;
    }

    @Override
    public String toString() {
        return "Motorista: \n"
                + "numerodaCNH: " + numCNH
                + "salario: " + salario
                + "categoriaPrincipal: "
                + catPrincipal;

    }
}