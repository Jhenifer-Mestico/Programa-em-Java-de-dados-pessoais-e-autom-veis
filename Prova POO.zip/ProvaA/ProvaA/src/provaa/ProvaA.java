package provaa;

public class ProvaA {

    public static void main(String[] args) {

        Motorista objMotorista = new Motorista(3455436, 1598f, "A");
        objMotorista.setNome("Anna");
        objMotorista.setAltura(1.78f);
        objMotorista.setPeso(65);
        objMotorista.setIdade(109);

        System.out.println("O salário será: " + objMotorista.calculoFerias());

        objMotorista.qtdDeDiasDeFerias();

        System.out.println(objMotorista.motoristaCatC());

        Motorista objMotorista1 = new Motorista(6446787, 4327f, "B");
        objMotorista1.setNome("Laís");
        objMotorista1.setAltura(1.48f);
        objMotorista1.setPeso(95);
        objMotorista1.setIdade(87);

        System.out.println("O salário será: " + objMotorista1.calculoFerias());

        objMotorista1.qtdDeDiasDeFerias();

        System.out.println(objMotorista1.motoristaCatC());

        Motorista objMotorista2 = new Motorista(765489, 6532f, "C");
        objMotorista2.setNome("Joel");
        objMotorista2.setAltura(1.98f);
        objMotorista2.setPeso(175);
        objMotorista2.setIdade(19);

        System.out.println("O salário será: " +objMotorista2.calculoFerias());
        objMotorista2.qtdDeDiasDeFerias();
        System.out.println(objMotorista2.motoristaCatC());

        Motorista objMotorista3 = new Motorista(742699, 5421f, "D");
        objMotorista3.setNome("Marcos");
        objMotorista3.setAltura(1.68f);
        objMotorista3.setPeso(56);
        objMotorista3.setIdade(33);

        System.out.println("O salário será: " + objMotorista3.calculoFerias());
        objMotorista3.qtdDeDiasDeFerias();
        System.out.println(objMotorista3.motoristaCatC());

    }

}